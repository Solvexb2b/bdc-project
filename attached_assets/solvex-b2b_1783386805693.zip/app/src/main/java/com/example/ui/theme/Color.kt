package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Clean Minimalism Color Palette (Extracted from Design HTML)
val MinimalistBackground = Color(0xFFF7F2FA)      // Main canvas background
val MinimalistSurface = Color(0xFFFFFFFF)         // Clean white panels/cards
val MinimalistSurfaceVariant = Color(0xFFF3EDF7)  // Secondary containment / Bottom Navigation
val MinimalistPrimary = Color(0xFF6750A4)         // Material 3 Deep Purple Accent
val MinimalistSecondary = Color(0xFF625B71)       // Neutral Dark
val MinimalistTertiary = Color(0xFF7D5260)        // Warm Contrast Accent
val MinimalistOnBackground = Color(0xFF1C1B1F)    // Dark Charcoal typography
val MinimalistOnSurface = Color(0xFF1C1B1F)       // High-readability surface text
val MinimalistOnPrimary = Color(0xFFFFFFFF)       // Crisp white text on primary actions
val MinimalistBorder = Color(0x30CAC4D0)          // Soft border line (30% alpha for #CAC4D0)
val MinimalistBorderSolid = Color(0xFFCAC4D0)     // Solid border line
val MinimalistPrimaryContainer = Color(0xFFEADDFF)// Welcome/Hero section bg
val MinimalistOnPrimaryContainer = Color(0xFF21005D)// Dark purple high-contrast stats value
