package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyberPrimary = Color(0xFF00FF90)      // Neon Emerald - Active / Verified / Proved
val CyberSecondary = Color(0xFF00E5FF)    // Cyber Teal - Interactive / Info / UI Accent
val CyberTertiary = Color(0xFFFFB300)     // Amber Gold - Secure Escrow / Challenge Pending
val CyberBackground = Color(0xFF0B0D11)   // Dark Slate Space - Deep Background
val CyberSurface = Color(0xFF131722)      // Obsidian Card Surface - Higher Depth
val CyberSurfaceVariant = Color(0xFF1B2030) // Raised Depth Border
val CyberTextBright = Color(0xFFF0F6FC)   // Crisp Silver White - Header
val CyberTextMuted = Color(0xFF8B949E)    // Charcoal Muted Gray - Secondary Text
val CyberAlertRed = Color(0xFFFF4D4D)     // Neon Red - Alert / Terminated / Error
val CyberBlueAccent = Color(0xFF2F80ED)   // Deep Tech Blue - Hardware Enclave Active
val CyberDivider = Color(0xFF212631)      // Structural lines
val CyberOnPrimary = Color(0xFF05070A)    // High contrast dark text on neon emerald

